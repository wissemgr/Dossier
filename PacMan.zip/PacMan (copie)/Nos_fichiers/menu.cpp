#include <iostream>
#include <fstream>
#include <string>
#include <cstdlib>
using namespace std;

void AfficheFich (const string & kfichier) // Affiche les Fichiers
{
    ifstream texte (kfichier.c_str());
    if(texte.is_open() == true)
    {
        string ligne;
        while (getline(texte, ligne))
        {
            cout << ligne << endl;
        }
    }

    else
    {
        cout << "ERRUR AFFICHAGE" << endl;
    }
}


void PileouFace (unsigned valeur, bool resultat){
    unsigned cote;
    srand(time(NULL));
    cote = rand() % 2 + 1;
    if (valeur == cote)
    {
        cout << cote <<"    " << "Bravo vous avez trouvé le bon coté" <<endl;
        resultat = true;
    }
    else {
        cout << cote << "   " << "Dommage vous n'avez pas trouvé le bon coté" << endl;
        resultat = false;
    }
}


int menu () { // int menu dans le projet (servira à choisir menu)
    string const fichier("accueil.txt");
    unsigned choix = 0;
    AfficheFich(fichier);
    cout << "choisir un truc :  ";
    unsigned reponse;
    cin >> reponse;
    while (true)
    {
        if (reponse == 1)
        {
            break;
        }
        if (reponse == 2)
        {
            cout << "\033[H\033[2J";
            string const fichier ("parametre.txt");
            AfficheFich(fichier); // faudra faire un return sur un int parametre
            break; // ou alors enlever le break
        }
        else {
            exit(0);
        }
    }
    return 0;
}
