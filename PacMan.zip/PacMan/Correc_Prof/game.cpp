#include <iostream>

#include "game.h"
#include "params.h"
#include "gridmanagement.h"
#include "Nos_fichiers/menu.h"

#include <map>
using namespace std;
template <class T, class U>
void ShowMap (const map<T,U> & AMap){
    for (const pair <T,U> & Val : AMap)                cout << "Cle : " << Val.first << "  "             << "Valeur : " << Val.second << endl;
    cout << endl;
}// ShowMap ()


void Teleporteur (CMat & Mat, CPosition & PosPlayer1, CPosition & PosPlayer2)
{
    Mat[6][3] = '*';
    Mat[3][8] = '*';

    if (Mat [PosPlayer1.first][PosPlayer1.second] == Mat[6][3])
    {

    Mat [PosPlayer1.first][PosPlayer1.second] = Mat[3][8];
    Mat[6][3] = '*';
    }


    if (Mat [PosPlayer1.first][PosPlayer1.second] == Mat[3][8])
    {

    Mat [PosPlayer1.first][PosPlayer1.second] = Mat[6][3];
    Mat[3][8] = '*';
    }

    if (Mat [PosPlayer2.first][PosPlayer2.second] == Mat[6][3])
    {

    Mat [PosPlayer2.first][PosPlayer2.second] = Mat[3][8];
    Mat[6][3] = '*';
    }


    if (Mat [PosPlayer2.first][PosPlayer2.second] == Mat[3][8])
    {

    Mat [PosPlayer2.first][PosPlayer2.second] = Mat[6][3];
    Mat[3][8] = '*';
    }
}


void MoveToken (CMat & Mat, const char & Move, CPosition & Pos)
{
    char car = Mat [Pos.first][Pos.second];
    Mat [Pos.first][Pos.second] = KEmpty;
    switch (Move)
    {
    case 'A':
        if (Pos.first == 0) {
            Pos.first = Mat.size()-1;
        } else {
            -- Pos.first;
        }

        if (Pos.second == 0) {
            Pos.second = Mat[Pos.first].size()-1;
        } else {
            -- Pos.second;
        }
        break;
    case 'Z':
        if (Pos.first == 0) {
            Pos.first = Mat.size()-1;
        }else {
            --Pos.first;
        }

        break;
    case 'E':
        if (Pos.first == 0) {
            Pos.first = Mat.size()-1;
        } else {
            -- Pos.first;
        }

        if (Pos.second == Mat[Pos.first].size()-1) {
            Pos.second = 0;
        } else {
            ++ Pos.second;
        }
        break;
    case 'Q':
        if (Pos.second == 0) {
            Pos.second = Mat[Pos.first].size()-1;
        } else {
            --Pos.second;
        }

        break;
    case 'D':
        if (Pos.second == Mat[Pos.first].size()-1) {
            Pos.second = 0;
        } else {
            ++Pos.second;
        }
        break;
    case 'W':

        if (Pos.first == Mat.size()-1) {
            Pos.first = 0;
        } else {
            ++ Pos.first;
        }
        if (Pos.second == 0) {
            Pos.second = Mat[Pos.first].size()-1;
        } else {
            -- Pos.second;
        }
        break;
    case 'S':
        if (Pos.first == Mat.size()-1) {
            Pos.first = 0;
        }else {
            ++Pos.first;
        }
        break;
    case 'C':

        if (Pos.first == Mat.size()-1) {
            Pos.first = 0;
        } else {
            ++ Pos.first;
        }

        if (Pos.second == Mat[Pos.first].size()-1) {
            Pos.second = 0;
        } else {
            ++ Pos.second;
        }
        break;
    }
    Mat [Pos.first][Pos.second] = car;
} //MoveToken ()


bool PileouFace (unsigned valeur){
    bool resultat;
    unsigned cote;
    srand(time(NULL));
    cote = rand() % 2 + 1;
    if (valeur == cote)
    {
        resultat = true;
    }
    else {
        resultat = false;
    }
    return resultat;
}

int ppal (void)
{
    unsigned saisi(0);
    const unsigned KSize (10);
    unsigned PartyNum (1);
    const unsigned KMaxPartyNum (KSize * KSize);
    CMat Mat;
    cout << "\033[H\033[2J";
    AfficheFich("CoinFlip.txt");
    cin >> saisi;
    bool Player1Turn (PileouFace(saisi));
    bool Victory (false);

    CPosition PosPlayer1, PosPlayer2;

    CMyParam Param;
    int RetVal = LoadParams(Param, "../PacMan/Nos_fichiers/config.yaml");
    if (RetVal != 0)
    {
        return RetVal;
    }


    InitGrid(Mat, Param, PosPlayer1, PosPlayer2);

    DisplayGrid (Mat, Param);
    if(Player1Turn == true)
    {
        cout << "Bravo Joueur 1, vous avez gagné le pile ou face" <<endl;
    }
    else
    {
        cout << "Dommage Joueur 1, vous n'avez pas gagné le pile ou face" << endl;

    }
    while (PartyNum <= KMaxPartyNum && ! Victory)
    {
        cout << "tour numero : " << PartyNum << ", Joueur"
             << (Player1Turn ? '1' : '2') << ", entrez un déplacement : ";

        char Move;
        cin >> Move;

        Move = toupper (Move);
        MoveToken (Mat, Move, (Player1Turn ? PosPlayer1: PosPlayer2));
        ClearScreen();
        DisplayGrid (Mat, Param);

        //Victiry test
        if (PosPlayer1 == PosPlayer2) Victory = true;

        //Increase party's number
        ++PartyNum;

        //Player changing
        Player1Turn = !Player1Turn;
    }//while (no victory)

    if (!Victory)
    {
        Color (KColor.find("KMAgenta")->second);
        cout << "Aucun vainqueur" << endl;
        return 1;
    }

    Color (KColor.find("KGreen")->second);
    cout << "Félicitations Joueur" << (Player1Turn ? '2' : '1')
         << " vous avez gagné :)" << endl;
    Color (KColor.find("KReset")->second);
    return 0;
} //ppal ()
