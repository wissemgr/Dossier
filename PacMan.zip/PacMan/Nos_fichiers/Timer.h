#ifndef TIMER_H
#define TIMER_H

void wait (int seconds);

#endif // TIMER_H
