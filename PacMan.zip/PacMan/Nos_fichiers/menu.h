#ifndef MENU_H
#define MENU_H
#include <string>

/*!
 * \file menu.h
 * \brief affiche diférent menu
 * \author Maldonado Kevin
 * \author Bennai Yanis
 * \author Tadrist Ghiles
 * \author Allali Djessim
 * \author Ghouili Wissem
 * \version 1.0
 * \date 05 janvie 2021
 */

void AfficheFich (const std::string & kfichier);

int menu();
#endif // MENU_H

