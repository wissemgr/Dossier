#include <iostream>
#include <fstream>
#include <string>
#include <cstdlib>
using namespace std;

void AfficheFich (const string & kfichier) // Affiche les Fichiers
{
    // if (! ofs.is_open()){
    // cout << "Erreur" << endl;
    // return;
    ifstream texte (kfichier.c_str());
    if(texte.is_open() == true)
    {
        string ligne;
        while (getline(texte, ligne))
        {
            cout << ligne << endl;
        }
    }

    else
    {
        cout << "ERRUR AFFICHAGE" << endl;
    }
}




int menu () { // int menu dans le projet (servira à choisir menu)
    string const fichier("accueil.txt");
    AfficheFich(fichier);
    cout << "choisir un truc :  ";
    unsigned reponse;
    cin >> reponse;
    while (true)
    {
        if (reponse == 1)
        {
            break;
        }
        if (reponse == 2)
        {
            cout << "\033[H\033[2J";
            string const fichier ("parametre.txt");
            AfficheFich(fichier); // faudra faire un return sur un int parametre
            break; // ou alors enlever le break
        }
        else {
            exit(0);
        }
    }
    return 0;
}
