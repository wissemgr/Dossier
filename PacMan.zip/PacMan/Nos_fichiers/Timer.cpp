#include <iostream>
#include <fstream>
#include <string>
#include <termios.h>

using namespace std;

void wait (int seconds)
{
  clock_t endwait;
  endwait = clock() + seconds * CLOCKS_PER_SEC ;
  while (clock() < endwait) {}
}

bool Timer ()
{
bool bon = true;
int debut=5;

while(bon == true)
   {
    if (debut == 0)
    {
        bon=false;
        break;
    }
    debut = debut - 1;
    cout << debut << endl;
    wait(1);
   }

   return bon;
}
