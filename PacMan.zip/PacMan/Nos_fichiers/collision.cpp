#include <iostream>

using namespace std;

//fonction qui detecte ce qui a prochaine case
//si x+1 = ''
//return vrai
