var searchData=
[
  ['params_2eh',['params.h',['../params_8h.html',1,'']]],
  ['ppal',['ppal',['../game_8cpp.html#acfd932870183388e95db32d747ebaad0',1,'ppal(void):&#160;game.cpp'],['../game_8h.html#a0b1d64ee76933ef8f007f1208cb869a7',1,'ppal():&#160;game.cpp']]]
];
